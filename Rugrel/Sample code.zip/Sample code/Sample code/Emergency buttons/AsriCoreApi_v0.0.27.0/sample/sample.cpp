#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <vector>
#include "AsrCore.h"
#include "AsrError.h"
#include "IADTTestMenu.h"
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::vector;

//==================================================================
#define ASR_ITEM_NAME_SIZE			20
#define IGNORE_STREAM_BUFFER_SIZE	1024

//==================================================================
void DisplayError(ULONG ErrorCode);
void ShowError(bool bSuccess);

//==================================================================
void DisplayError(ULONG ErrorCode)
{
	switch (ErrorCode)
	{
	case ERRLIB_SUCCESS:
		printf("ERRLIB_SUCCESS");
		break;
	case ERRLIB_DLL_NOT_INIT:
		printf("ERRLIB_DLL_NOT_INIT");
		break;
	case ERRLIB_PLATFORM_UNSUPPORT:
		printf("ERRLIB_PLATFORM_UNSUPPORT");
		break;
	case ERRLIB_API_UNSUPPORT:
		printf("ERRLIB_API_UNSUPPORT");
		break;
	case ERRLIB_API_CURRENT_UNSUPPORT:
		printf("ERRLIB_API_CURRENT_UNSUPPORT");
		break;
	case ERRLIB_LIB_INIT_FAIL:
		printf("ERRLIB_LIB_INIT_FAIL");
		break;
	case ERRLIB_INVALID_PARAMETER:
		printf("ERRLIB_INVALID_PARAMETER");
		break;
	case ERRLIB_INVALID_ID:
		printf("ERRLIB_INVALID_ID");
		break;
	case ERRLIB_OUTBUF_RETURN_SIZE_INCORRECT:
		printf("ERRLIB_OUTBUF_RETURN_SIZE_INCORRECT");
		break;
	case ERRLIB_ARRAY_LENGTH_INSUFFICIENT:
		printf("ERRLIB_ARRAY_LENGTH_INSUFFICIENT");
		break;
	case ERRLIB_THREAD_LOCKED:
		printf("ERRLIB_THREAD_LOCKED");
		break;
	case ERRLIB_LIB_INVALID_VERSION:
		printf("ERRLIB_LIB_INVALID_VERSION");
		break;
	case ERRLIB_USAGE_NOT_SUPPORT:
		printf("ERRLIB_USAGE_NOT_SUPPORT");
		break;
	case ERRLIB_UNKNOWN_GROUP:
		printf("ERRLIB_UNKNOWN_GROUP");
		break;
	case ERRLIB_CONDITION_MATCH:
		printf("ERRLIB_CONDITION_MATCH");
		break;
	case ERRLIB_CONDITION_NOT_MATCH:
		printf("ERRLIB_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_NO_CHIP_ID_FUNCTION:
		printf("ERRLIB_NO_CHIP_ID_FUNCTION");
		break;
	case ERRLIB_NO_BOARD_INFO_TABLE:
		printf("ERRLIB_NO_BOARD_INFO_TABLE");
		break;
	case ERRLIB_UNKNOWN_CHIP_ID:
		printf("ERRLIB_UNKNOWN_CHIP_ID");
		break;
	case ERRLIB_CHIP_ID_NOT_MATCH:
		printf("ERRLIB_CHIP_ID_NOT_MATCH");
		break;
	case ERRLIB_CHIP_ID_TABLE_BREAK:
		printf("ERRLIB_CHIP_ID_TABLE_BREAK");
		break;
	case ERRLIB_UNKNOWN_INTERFACE:
		printf("ERRLIB_UNKNOWN_INTERFACE");
		break;
	case ERRLIB_NO_COM_TYPE_TABLE:
		printf("ERRLIB_NO_COM_TYPE_TABLE");
		break;
	case ERRLIB_GET_COM_TYPE_FAILED:
		printf("ERRLIB_GET_COM_TYPE_FAILED");
		break;
	case ERRLIB_SET_COM_TYPE_FAILED:
		printf("ERRLIB_SET_COM_TYPE_FAILED");
		break;
	case ERRLIB_COM_CONDITION_NOT_MATCH:
		printf("ERRLIB_COM_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_NO_SPECIFIED_COM_TABLE:
		printf("ERRLIB_NO_SPECIFIED_COM_TABLE");
		break;
	case ERRLIB_NO_VOLTAGE_TABLE:
		printf("ERRLIB_NO_VOLTAGE_TABLE");
		break;
	case ERRLIB_GET_VOLTAGE_TYPE1_FAILED:
		printf("ERRLIB_GET_VOLTAGE_TYPE1_FAILED");
		break;
	case ERRLIB_GET_VOLTAGE_TYPE2_FAILED:
		printf("ERRLIB_GET_VOLTAGE_TYPE2_FAILED");
		break;
	case ERRLIB_VOLTAGE_CONDITION_NOT_MATCH:
		printf("ERRLIB_VOLTAGE_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_VOLTAGE_ITEMS_COUNT_NOT_MATCH:
		printf("ERRLIB_VOLTAGE_ITEMS_COUNT_NOT_MATCH");
		break;
	case ERRLIB_NO_SPECIFIED_VOLTAGE_TABLE:
		printf("ERRLIB_NO_SPECIFIED_VOLTAGE_TABLE");
		break;
	case ERRLIB_GET_VOLTAGE_TYPE3_FAILED:
		printf("ERRLIB_GET_VOLTAGE_TYPE3_FAILED");
		break;
	case ERRLIB_NO_TEMPERATURE_TABLE:
		printf("ERRLIB_NO_TEMPERATURE_TABLE");
		break;
	case ERRLIB_GET_TEMPERATURE_TYPE1_FAILED:
		printf("ERRLIB_GET_TEMPERATURE_TYPE1_FAILED");
		break;
	case ERRLIB_GET_TEMPERATURE_TYPE2_FAILED:
		printf("ERRLIB_GET_TEMPERATURE_TYPE2_FAILED");
		break;
	case ERRLIB_TEMPERATURE_CONDITION_NOT_MATCH:
		printf("ERRLIB_TEMPERATURE_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_TEMPERATURE_ITEMS_COUNT_NOT_MATCH:
		printf("ERRLIB_TEMPERATURE_ITEMS_COUNT_NOT_MATCH");
		break;
	case ERRLIB_NO_SPECIFIED_TEMPERATURE_TABLE:
		printf("ERRLIB_NO_SPECIFIED_TEMPERATURE_TABLE");
		break;
	case ERRLIB_GET_TEMPERATURE_TYPE3_FAILED:
		printf("ERRLIB_GET_TEMPERATURE_TYPE3_FAILED");
		break;
	case ERRLIB_GET_TEMPERATURE_TYPE4_FAILED:
		printf("ERRLIB_GET_TEMPERATURE_TYPE4_FAILED");
		break;
	case ERRLIB_NO_FAN_SPEED_TABLE:
		printf("ERRLIB_NO_FAN_SPEED_TABLE");
		break;
	case ERRLIB_GET_FAN_TYPE1_FAILED:
		printf("ERRLIB_GET_FAN_TYPE1_FAILED");
		break;
	case ERRLIB_GET_FAN_TYPE2_FAILED:
		printf("ERRLIB_GET_FAN_TYPE2_FAILED");
		break;
	case ERRLIB_GET_FAN_TYPE3_FAILED:
		printf("ERRLIB_GET_FAN_TYPE3_FAILED");
		break;
	case ERRLIB_FAN_SPEED_CONDITION_NOT_MATCH:
		printf("ERRLIB_FAN_SPEED_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_FAN_ITEMS_COUNT_NOT_MATCH:
		printf("ERRLIB_FAN_ITEMS_COUNT_NOT_MATCH");
		break;
	case ERRLIB_NO_SPECIFIED_FAN_TABLE:
		printf("ERRLIB_NO_SPECIFIED_FAN_TABLE");
		break;
	case ERRLIB_NO_LVDS_ENABLE_TABLE:
		printf("ERRLIB_NO_LVDS_ENABLE_TABLE");
		break;
	case ERRLIB_GET_LVDS_STATE_FAILED:
		printf("ERRLIB_GET_LVDS_STATE_FAILED");
		break;
	case ERRLIB_SET_LVDS_STATE_FAILED:
		printf("ERRLIB_SET_LVDS_STATE_FAILED");
		break;
	case ERRLIB_LVDS_ENABLE_CONDITION_NOT_MATCH:
		printf("ERRLIB_LVDS_ENABLE_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_LVDS_NO_THIS_STATE_TABLE:
		printf("ERRLIB_LVDS_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_LVDS_TYPE_TABLE:
		printf("ERRLIB_NO_LVDS_TYPE_TABLE");
		break;
	case ERRLIB_GET_LVDS_TYPE_FAILED:
		printf("ERRLIB_GET_LVDS_TYPE_FAILED");
		break;
	case ERRLIB_SET_LVDS_TYPE_FAILED:
		printf("ERRLIB_SET_LVDS_TYPE_FAILED");
		break;
	case ERRLIB_LVDS_TYPE_CONDITION_NOT_MATCH:
		printf("ERRLIB_LVDS_TYPE_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_LVDS_TYPE_NO_THIS_TYPE_TABLE:
		printf("ERRLIB_LVDS_TYPE_NO_THIS_TYPE_TABLE");
		break;
	case ERRLIB_NO_MFG_TABLE:
		printf("ERRLIB_NO_MFG_TABLE");
		break;
	case ERRLIB_GET_MFG_STATE_FAILED:
		printf("ERRLIB_GET_MFG_STATE_FAILED");
		break;
	case ERRLIB_NO_ONBOARD_TPM_TABLE:
		printf("ERRLIB_NO_ONBOARD_TPM_TABLE");
		break;
	case ERRLIB_GET_ONBOARD_TPM_FAILED:
		printf("ERRLIB_GET_ONBOARD_TPM_FAILED");
		break;
	case ERRLIB_SET_ONBOARD_TPM_FAILED:
		printf("ERRLIB_SET_ONBOARD_TPM_FAILED");
		break;
	case ERRLIB_ONBOARD_TPM_CONDITION_NOT_MATCH:
		printf("ERRLIB_ONBOARD_TPM_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_ONBOARD_TPM_NO_THIS_STATE_TABLE:
		printf("ERRLIB_ONBOARD_TPM_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_ME_DESCRIPTOR_TABLE:
		printf("ERRLIB_NO_ME_DESCRIPTOR_TABLE");
		break;
	case ERRLIB_GET_ME_DESCRIPTOR_FAILED:
		printf("ERRLIB_GET_ME_DESCRIPTOR_FAILED");
		break;
	case ERRLIB_SET_ME_DESCRIPTOR_FAILED:
		printf("ERRLIB_SET_ME_DESCRIPTOR_FAILED");
		break;
	case ERRLIB_ME_DESCRIPTOR_CONDITION_NOT_MATCH:
		printf("ERRLIB_ME_DESCRIPTOR_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_ME_DESCRIPTOR_NO_THIS_STATE_TABLE:
		printf("ERRLIB_ME_DESCRIPTOR_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_PCIE_BANDWIDTH_TABLE:
		printf("ERRLIB_NO_PCIE_BANDWIDTH_TABLE");
		break;
	case ERRLIB_GET_PCIE_BANDWIDTH_FAILED:
		printf("ERRLIB_GET_PCIE_BANDWIDTH_FAILED");
		break;
	case ERRLIB_NO_USB_POWER_TABLE:
		printf("ERRLIB_NO_USB_POWER_TABLE");
		break;
	case ERRLIB_GET_USB_POWER_FAILED:
		printf("ERRLIB_GET_USB_POWER_FAILED");
		break;
	case ERRLIB_SET_USB_POWER_FAILED:
		printf("ERRLIB_SET_USB_POWER_FAILED");
		break;
	case ERRLIB_USB_POWER_CONDITION_NOT_MATCH:
		printf("ERRLIB_USB_POWER_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_USB_POWER_NO_THIS_STATE_TABLE:
		printf("ERRLIB_USB_POWER_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_BLUE_TOOTH_TABLE:
		printf("ERRLIB_NO_BLUE_TOOTH_TABLE");
		break;
	case ERRLIB_GET_BLUE_TOOTH_FAILED:
		printf("ERRLIB_GET_BLUE_TOOTH_FAILED");
		break;
	case ERRLIB_SET_BLUE_TOOTH_FAILED:
		printf("ERRLIB_SET_BLUE_TOOTH_FAILED");
		break;
	case ERRLIB_BLUE_TOOTH_CONDITION_NOT_MATCH:
		printf("ERRLIB_BLUE_TOOTH_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_BLUE_TOOTH_NO_THIS_STATE_TABLE:
		printf("ERRLIB_BLUE_TOOTH_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_WIFI_TABLE:
		printf("ERRLIB_NO_WIFI_TABLE");
		break;
	case ERRLIB_GET_WIFI_FAILED:
		printf("ERRLIB_GET_WIFI_FAILED");
		break;
	case ERRLIB_SET_WIFI_FAILED:
		printf("ERRLIB_SET_WIFI_FAILED");
		break;
	case ERRLIB_WIFI_CONDITION_NOT_MATCH:
		printf("ERRLIB_WIFI_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_WIFI_NO_THIS_STATE_TABLE:
		printf("ERRLIB_WIFI_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_OTP_TABLE:
		printf("ERRLIB_NO_OTP_TABLE");
		break;
	case ERRLIB_GET_OTP_FAILED:
		printf("ERRLIB_GET_OTP_FAILED");
		break;
	case ERRLIB_SET_OTP_FAILED:
		printf("ERRLIB_SET_OTP_FAILED");
		break;
	case ERRLIB_OTP_CONDITION_NOT_MATCH:
		printf("ERRLIB_OTP_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_OTP_NO_THIS_STATE_TABLE:
		printf("ERRLIB_OTP_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_LAN_POWER_GOOD_TABLE:
		printf("ERRLIB_NO_LAN_POWER_GOOD_TABLE");
		break;
	case ERRLIB_GET_LAN_POWER_GOOD_FAILED:
		printf("ERRLIB_GET_LAN_POWER_GOOD_FAILED");
		break;
	case ERRLIB_SET_LAN_POWER_GOOD_FAILED:
		printf("ERRLIB_SET_LAN_POWER_GOOD_FAILED");
		break;
	case ERRLIB_LAN_POWER_GOOD_CONDITION_NOT_MATCH:
		printf("ERRLIB_LAN_POWER_GOOD_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_LAN_POWER_GOOD_NO_THIS_STATE_TABLE:
		printf("ERRLIB_LAN_POWER_GOOD_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_AT_MODE_TABLE:
		printf("ERRLIB_NO_AT_MODE_TABLE");
		break;
	case ERRLIB_GET_AT_MODE_FAILED:
		printf("ERRLIB_GET_AT_MODE_FAILED");
		break;
	case ERRLIB_NO_INTEL_POWER_SOLUTION_TABLE:
		printf("ERRLIB_NO_INTEL_POWER_SOLUTION_TABLE");
		break;
	case ERRLIB_GET_INTEL_POWER_SOLUTION_FAILED:
		printf("ERRLIB_GET_INTEL_POWER_SOLUTION_FAILED");
		break;
	case ERRLIB_SET_INTEL_POWER_SOLUTION_FAILED:
		printf("ERRLIB_SET_INTEL_POWER_SOLUTION_FAILED");
		break;
	case ERRLIB_INTEL_PWR_SOL_CONDITION_NOT_MATCH:
		printf("ERRLIB_INTEL_PWR_SOL_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_INTEL_PWR_SOL_NO_THIS_STATE_TABLE:
		printf("ERRLIB_INTEL_PWR_SOL_NO_THIS_STATE_TABLE");
		break;
	case ERRLIB_NO_THUNDERBOLT_PLUG_TABLE:
		printf("ERRLIB_NO_THUNDERBOLT_PLUG_TABLE");
		break;
	case ERRLIB_GET_THUNDERBOLT_PLUG_FAILED:
		printf("ERRLIB_GET_THUNDERBOLT_PLUG_FAILED");
		break;
	case ERRLIB_NO_THUNDERBOLT_POWER_TABLE:
		printf("ERRLIB_NO_THUNDERBOLT_POWER_TABLE");
		break;
	case ERRLIB_GET_THUNDERBOLT_POWER_FAILED:
		printf("ERRLIB_GET_THUNDERBOLT_POWER_FAILED");
		break;
	case ERRLIB_NO_MB_VERSION_TABLE:
		printf("ERRLIB_NO_MB_VERSION_TABLE");
		break;
	case ERRLIB_GET_MB_VERSION_FAILED:
		printf("ERRLIB_GET_MB_VERSION_FAILED");
		break;
	case ERRLIB_NO_DIGITAL_IO_TABLE:
		printf("ERRLIB_NO_DIGITAL_IO_TABLE");
		break;
	case ERRLIB_GET_DIGITAL_IO_FAILED:
		printf("ERRLIB_GET_DIGITAL_IO_FAILED");
		break;
	case ERRLIB_SET_DIGITAL_IO_FAILED:
		printf("ERRLIB_SET_DIGITAL_IO_FAILED");
		break;
	case ERRLIB_DIGITAL_IO_CONDITION_NOT_MATCH:
		printf("ERRLIB_DIGITAL_IO_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_DIGITAL_IO_NO_SPECIFIED_DIO_TABLE:
		printf("ERRLIB_DIGITAL_IO_NO_SPECIFIED_DIO_TABLE");
		break;
	case ERRLIB_NO_WATCH_DOG_TABLE:
		printf("ERRLIB_NO_WATCH_DOG_TABLE");
		break;
	case ERRLIB_WDT_ACTIVATE_FAILED:
		printf("ERRLIB_WDT_ACTIVATE_FAILED");
		break;
	case ERRLIB_WDT_GET_INTERVAL_FAILED:
		printf("ERRLIB_WDT_GET_INTERVAL_FAILED");
		break;
	case ERRLIB_WDT_SET_INTERVAL_FAILED:
		printf("ERRLIB_WDT_SET_INTERVAL_FAILED");
		break;
	case ERRLIB_WDT_COUNTING_FAILED:
		printf("ERRLIB_WDT_COUNTING_FAILED");
		break;
	case ERRLIB_WDT_GET_COUNT_MODE_FAILED:
		printf("ERRLIB_WDT_GET_COUNT_MODE_FAILED");
		break;
	case ERRLIB_WDT_SET_COUNT_MODE_FAILED:
		printf("ERRLIB_WDT_SET_COUNT_MODE_FAILED");
		break;
	case ERRLIB_WDT_COUNT_MODE_NOT_SUPPORT:
		printf("ERRLIB_WDT_COUNT_MODE_NOT_SUPPORT");
		break;
	case ERRLIB_WDT_CONDITION_NOT_MATCH:
		printf("ERRLIB_WDT_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_WDT_NO_COUNTING_TABLE:
		printf("ERRLIB_WDT_NO_COUNTING_TABLE");
		break;
	case ERRLIB_WDT_NO_COUNT_MODE_TABLE:
		printf("ERRLIB_WDT_NO_COUNT_MODE_TABLE");
		break;
	case ERRLIB_NO_FAN_MODE_TABLE:
		printf("ERRLIB_NO_FAN_MODE_TABLE");
		break;
	case ERRLIB_GET_FAN_MODE_FAILED:
		printf("ERRLIB_GET_FAN_MODE_FAILED");
		break;
	case ERRLIB_SET_FAN_MODE_FAILED:
		printf("ERRLIB_SET_FAN_MODE_FAILED");
		break;
	case ERRLIB_FAN_MODE_CONDITION_NOT_MATCH:
		printf("ERRLIB_FAN_MODE_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_FAN_CONFIG_INPUT_ERROR:
		printf("ERRLIB_FAN_CONFIG_INPUT_ERROR");
		break;
	case ERRLIB_FAN_CONFIG_PARAM_NOT_MATCH:
		printf("ERRLIB_FAN_CONFIG_PARAM_NOT_MATCH");
		break;
	case ERRLIB_FAN_MODE_NO_SPECIFIED_MODE_TABLE:
		printf("ERRLIB_FAN_MODE_NO_SPECIFIED_MODE_TABLE");
		break;
	case ERRLIB_NO_LVDS_BACKLIGHT_TABLE:
		printf("ERRLIB_NO_LVDS_BACKLIGHT_TABLE");
		break;
	case ERRLIB_SET_LVDS_BACKLIGHT_FAILED:
		printf("ERRLIB_SET_LVDS_BACKLIGHT_FAILED");
		break;
	case ERRLIB_LVDS_BACKLIGHT_CONDITION_NOT_MATCH:
		printf("ERRLIB_LVDS_BACKLIGHT_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_LVDS_BACKLIGHT_NO_SPECIFIED_CONTROL_TABLE:
		printf("ERRLIB_LVDS_BACKLIGHT_NO_SPECIFIED_CONTROL_TABLE");
		break;
	case ERRLIB_NO_CURRENT_TABLE:
		printf("ERRLIB_NO_CURRENT_TABLE");
		break;
	case ERRLIB_COULD_NOT_GET_CURRENT:
		printf("ERRLIB_COULD_NOT_GET_CURRENT");
		break;
	case ERRLIB_CURRENT_CONDITION_NOT_MATCH:
		printf("ERRLIB_CURRENT_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_CURRENT_ITEMS_COUNT_NOT_MATCH:
		printf("ERRLIB_CURRENT_ITEMS_COUNT_NOT_MATCH");
		break;
	case ERRLIB_GET_CURRENT_TYPE1_FAILED:
		printf("ERRLIB_GET_CURRENT_TYPE1_FAILED");
		break;
	case ERRLIB_NO_SPECIFIED_CURRENT_TABLE:
		printf("ERRLIB_NO_SPECIFIED_CURRENT_TABLE");
		break;
	case ERRLIB_NO_USER_LED_TYPE1_TABLE:
		printf("ERRLIB_NO_USER_LED_TYPE1_TABLE");
		break;
	case ERRLIB_GET_USER_LED_TYPE1_FAILED:
		printf("ERRLIB_GET_USER_LED_TYPE1_FAILED");
		break;
	case ERRLIB_SET_USER_LED_TYPE1_FAILED:
		printf("ERRLIB_SET_USER_LED_TYPE1_FAILED");
		break;
	case ERRLIB_USER_LED_TYPE1_CONDITION_NOT_MATCH:
		printf("ERRLIB_USER_LED_TYPE1_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_NO_JGPIO_POWER_TABLE:
		printf("ERRLIB_NO_JGPIO_POWER_TABLE");
		break;
	case ERRLIB_GET_JGPIO_POWER_FAILED:
		printf("ERRLIB_GET_JGPIO_POWER_FAILED");
		break;
	case ERRLIB_SET_JGPIO_POWER_FAILED:
		printf("ERRLIB_SET_JGPIO_POWER_FAILED");
		break;
	case ERRLIB_JGPIO_POWER_CONDITION_NOT_MATCH:
		printf("ERRLIB_JGPIO_POWER_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_NO_COM_POWER_TABLE:
		printf("ERRLIB_NO_COM_POWER_TABLE");
		break;
	case ERRLIB_GET_COM_POWER_FAILED:
		printf("ERRLIB_GET_COM_POWER_FAILED");
		break;
	case ERRLIB_SET_COM_POWER_FAILED:
		printf("ERRLIB_SET_COM_POWER_FAILED");
		break;
	case ERRLIB_COM_POWER_CONDITION_NOT_MATCH:
		printf("ERRLIB_COM_POWER_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_NO_SPECIFIED_COM_POWER_TABLE:
		printf("ERRLIB_NO_SPECIFIED_COM_POWER_TABLE");
		break;
	case ERRLIB_NO_DBG_LED_TABLE:
		printf("ERRLIB_NO_DBG_LED_TABLE");
		break;
	case ERRLIB_GET_DBG_LED_FAILED:
		printf("ERRLIB_GET_DBG_LED_FAILED");
		break;
	case ERRLIB_SET_DBG_LED_FAILED:
		printf("ERRLIB_SET_DBG_LED_FAILED");
		break;
	case ERRLIB_DBG_LED_CONDITION_NOT_MATCH:
		printf("ERRLIB_DBG_LED_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_NO_SPECIFIED_DBG_LED_TABLE:
		printf("ERRLIB_NO_SPECIFIED_DBG_LED_TABLE");
		break;
	case ERRLIB_NO_USER_LED_TYPE2_TABLE:
		printf("ERRLIB_NO_USER_LED_TYPE2_TABLE");
		break;
	case ERRLIB_GET_USER_LED_TYPE2_FAILED:
		printf("ERRLIB_GET_USER_LED_TYPE2_FAILED");
		break;
	case ERRLIB_SET_USER_LED_TYPE2_FAILED:
		printf("ERRLIB_SET_USER_LED_TYPE2_FAILED");
		break;
	case ERRLIB_USER_LED_TYPE2_CONDITION_NOT_MATCH:
		printf("ERRLIB_USER_LED_TYPE2_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_NO_SPECIFIED_USER_LED_TYPE2_TABLE:
		printf("ERRLIB_NO_SPECIFIED_USER_LED_TYPE2_TABLE");
		break;
	case ERRLIB_NO_DIO_CONFIG_TABLE:
		printf("ERRLIB_NO_DIO_CONFIG_TABLE");
		break;
	case ERRLIB_GET_DIO_CONFIG_FAILED:
		printf("ERRLIB_GET_DIO_CONFIG_FAILED");
		break;
	case ERRLIB_SET_DIO_CONFIG_FAILED:
		printf("ERRLIB_SET_DIO_CONFIG_FAILED");
		break;
	case ERRLIB_DIO_CONFIG_CONDITION_NOT_MATCH:
		printf("ERRLIB_DIO_CONFIG_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_DIO_CONFIG_NO_SPECIFIED_DIO_TABLE:
		printf("ERRLIB_DIO_CONFIG_NO_SPECIFIED_DIO_TABLE");
		break;
	case ERRLIB_NO_DIO_EN_TABLE:
		printf("ERRLIB_NO_DIO_EN_TABLE");
		break;
	case ERRLIB_GET_DIO_EN_FAILED:
		printf("ERRLIB_GET_DIO_EN_FAILED");
		break;
	case ERRLIB_SET_DIO_EN_FAILED:
		printf("ERRLIB_SET_DIO_EN_FAILED");
		break;
	case ERRLIB_DIO_EN_CONDITION_NOT_MATCH:
		printf("ERRLIB_DIO_EN_CONDITION_NOT_MATCH");
		break;
	case ERRLIB_DIO_EN_NO_SPECIFIED_DIO_TABLE:
		printf("ERRLIB_DIO_EN_NO_SPECIFIED_DIO_TABLE");
		break;
	default:
		printf("UNKNOWN_ERROR");
	}

	printf("(0x%08lX)\n", ErrorCode);
}

void ShowError(bool bSuccess)
{
	if (!bSuccess)
	{
		DisplayError(AsrLibDllGetLastError());
	}
}

int main(int argc, char** argv)
{
	bool bSuccess = false;
	ShowError(bSuccess = AsrLibDllInit());

	if (bSuccess)
	{
		printf("==================================================================\n");

		int IADTFuncArraySize = sizeof(IADTFuncArray) / sizeof(TIADTFunctionArray);
#ifdef _DEBUG
		cout << "IADTFuncArraySize = " << IADTFuncArraySize << endl;
#endif
		vector<TIADTFunctionArray> SupportedFunctions;
		int MenuIndex = 0;

		for (int i = 0; i < IADTFuncArraySize; i++) {
			if (IADTFuncArray[i].IADTFunc(ASR_USAGE_IF_SUPPORTED))
				SupportedFunctions.push_back(IADTFuncArray[i]);
		}

		if (SupportedFunctions.size() == 0) {
			cout << "There are no functions in IAxT !!" << endl;
			return 1;
		}

		while (true)
		{
			for (int i = 0; i < SupportedFunctions.size(); i++){
			if(i >= 0 && i <=24) {
			continue; //skip printing optiuons 1-24
			}
					cout << "	" << (i + 1) << "." << SupportedFunctions[i].FunctionName << endl;
					}

			MenuIndex = 15;

			//cout << "Please input the function number or press \"Ctrl + C\" to exit: ";
			//cin >> MenuIndex;
			cout << endl;

			usleep(30000); // Delay 30 millisecond, the unit of usleep is micronsecond

			if ((MenuIndex > SupportedFunctions.size()) || (MenuIndex < 1)) {
				cout << "Error function number !!" << endl << endl;
				continue;
			}

			SupportedFunctions[--MenuIndex].IADTFunc(ASR_USAGE_CUSTOMER);

			cout << endl;
		}
	}
	else
	{
		printf("LibDll initial error !!\n");
		return 1;
	}

	AsrLibDllUnInit();

	return 0;
}

//==================================================================
int GetCOMType(int Usage)
{
	int ComNum = 0;
	UCHAR FunNum = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: COM1, 2: COM2, 3: COM3, 4: COM4, 5: COM5, 6: COM6..." << endl;
		cout << "Please input a number to get COM# type: " << endl;
		cin >> ComNum;

		if (ComNum > 0)
		{
			if (AsrLibGetComType((UCHAR)ComNum, &FunNum, Usage))
			{
				if (FunNum == ASR_FUN_RS232)
					printf("Com%d Status is RS232\n", ComNum);
				else if (FunNum == ASR_FUN_RS422)
					printf("Com%d Status is RS422\n", ComNum);
				else if (FunNum == ASR_FUN_RS485)
					printf("Com%d Status is RS485\n", ComNum);
				else if (FunNum == ASR_FUN_RS485_AUTO_FLOW)
					printf("Com%d Status is RS485_AUTO_FLOW\n", ComNum);
				else if (FunNum == ASR_FUN_ERROR)
					printf("Get Com%d Status error!!\n", ComNum);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetComType((UCHAR)ComNum, &FunNum, Usage);
	}

	return 0;
}

int SetCOMType(int Usage)
{
	int ComNum = 0;
	int FunNum = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: COM1, 2: COM2, 3: COM3, 4: COM4, 5: COM5, 6: COM6 ..." << endl;
		cout << "Please input a number to choose COM#: " << endl;
		cin >> ComNum;
		cout << "0: RS232, 1: RS422, 2: RS485, 3: RS485_AUTO_FLOW" << endl;
		cout << "Please input a number to configure COM" << ComNum << endl;
		cin >> FunNum;

		if (ComNum > 0 && FunNum >= 0)
		{
			if (!AsrLibSetComType((UCHAR)ComNum, (UCHAR)FunNum, Usage))
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
		else
		{
			printf("Input error!!\n");
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetComType((UCHAR)ComNum, (UCHAR)FunNum, Usage);
	}

	return 0;
}

int GetVoltage(int Usage)
{
	float VoltageValue = 0;
	char VoltageName[ASR_ITEM_NAME_SIZE] = "";

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		printf("Input the voltage name which should be less than %lu characters:\n", sizeof(VoltageName));

		cin.ignore(IGNORE_STREAM_BUFFER_SIZE, '\n');
		cin.getline(VoltageName, ASR_ITEM_NAME_SIZE);
#ifdef _DEBUG
		printf("GetVoltage::VoltageName = %s\n", VoltageName);
#endif

		if (AsrLibGetVoltage(VoltageName, &VoltageValue, Usage))
		{
			printf("%s = %3.3f V\n", VoltageName, VoltageValue);
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetVoltage(VoltageName, &VoltageValue, Usage);
	}

	return 0;
}

int GetTemperature(int Usage)
{
	float TempValue = 0;
	char TemperatureName[ASR_ITEM_NAME_SIZE] = "";

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		printf("Input the temperature name which should be less than %lu characters:\n", sizeof(TemperatureName));

		cin.ignore(IGNORE_STREAM_BUFFER_SIZE, '\n');
		cin.getline(TemperatureName, ASR_ITEM_NAME_SIZE);
#ifdef _DEBUG
		printf("GetTemperature::TemperatureName = %s\n", TemperatureName);
#endif

		if (AsrLibGetTemperature(TemperatureName, &TempValue, Usage))
		{
			printf("%s = %3.2f C\n", TemperatureName, TempValue);
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetTemperature(TemperatureName, &TempValue, Usage);
	}

	return 0;
}

int GetFanSpeed(int Usage)
{
	USHORT FanSpeed = 0;
	char FanName[ASR_ITEM_NAME_SIZE] = "";

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		printf("Input the FAN name which should be less than %lu characters:\n", sizeof(FanName));

		cin.ignore(IGNORE_STREAM_BUFFER_SIZE, '\n');
		cin.getline(FanName, ASR_ITEM_NAME_SIZE);
#ifdef _DEBUG
		printf("GetFanSpeed::FanName = %s\n", FanName);
#endif

		if (AsrLibGetFanSpeed(FanName, &FanSpeed, Usage))
		{
			printf("%s = %d RPM\n", FanName, FanSpeed);
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetFanSpeed(FanName, &FanSpeed, Usage);
	}

	return 0;
}

int GetCurrent(int Usage)
{
	float CurrentValue = 0;
	char CurrentName[ASR_ITEM_NAME_SIZE] = "";

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		printf("Input the current name which should be less than %zd characters:\n", sizeof(CurrentName));

		cin.ignore(IGNORE_STREAM_BUFFER_SIZE, '\n');
		cin.getline(CurrentName, ASR_ITEM_NAME_SIZE);
#ifdef _DEBUG
		printf("GetCurrent::CurrentName = %s\n", CurrentName);
#endif

		if (AsrLibGetCurrent(CurrentName, &CurrentValue, Usage))
		{
			printf("%s = %3.1f A\n", CurrentName, CurrentValue);
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetCurrent(CurrentName, &CurrentValue, Usage);
	}

	return 0;
}

int GetLVDSState(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetLVDSState(&State, Usage))
		{
			if (State == ASR_ENABLED)
				printf("LVDS is enable.\n");
			else if (State == ASR_DISABLED)
				printf("LVDS is disable!!\n");
			else
				printf("Can't get LVDS state!!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetLVDSState(&State, Usage);
	}

	return 0;
}

int GetLVDSType(int Usage)
{
	UCHAR PanelType = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetLVDSType(&PanelType, Usage))
		{
			printf("Current panel type is %d\n", PanelType);
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetLVDSType(&PanelType, Usage);
	}

	return 0;
}

int GetOnboardTPMState(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetOnboardTPMState(&State, Usage))
		{
			if (State == ASR_ENABLED)
				printf("Onboard TPM is enable.\n");
			else if (State == ASR_DISABLED)
				printf("Onboard TPM is disable.\n");
			else
				printf("Can't get Onboard TPM state !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetOnboardTPMState(&State, Usage);
	}

	return 0;
}

int GetUSBPwrState(int Usage)
{
	UCHAR USBPwrState = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetUsbPwrState(&USBPwrState, Usage))
		{
			if (USBPwrState == ASR_ENABLED)
				printf("USB power is enable.\n");
			else if (USBPwrState == ASR_DISABLED)
				printf("USB power is disable.\n");
			else
				printf("Can't get USB power state !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetUsbPwrState(&USBPwrState, Usage);
	}

	return 0;
}

int SetUSBPwrState(int Usage)
{
	int USBPwrState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "0: Disable, 1: Enable" << endl;
		cout << "Please input 0 or 1 to set USB Power disable/enable:" << endl;
		cin >> USBPwrState;

		if (AsrLibSetUsbPwrState((UCHAR)USBPwrState, Usage))
		{
			if (USBPwrState == ASR_ENABLED)
				printf("Set USB Power Enable.\n");
			else if (USBPwrState == ASR_DISABLED)
				printf("Set USB Power Disable.\n");
			else
				printf("Set USB Power error !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetUsbPwrState((UCHAR)USBPwrState, Usage);
	}

	return 0;
}

int GetBlueToothState(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetBTState(&State, Usage))
		{
			if (State == ASR_DISABLED)
				printf("Blue Tooth is Off.\n");
			else if (State == ASR_ENABLED)
				printf("Blue Tooth is On.\n");
			else
				printf("Can't get Blue Tooth state !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetBTState(&State, Usage);
	}

	return 0;
}

int SetBlueToothState(int Usage)
{
	int BlueToothState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: Blue Tooth On, 0: Blue Tooth Off" << endl;
		cout << "Please input 0 or 1 to enable/disable Blue Tooth:" << endl;
		cin >> BlueToothState;

		if (AsrLibSetBTState((UCHAR)BlueToothState, Usage))
		{
			if (BlueToothState == ASR_DISABLED)
				printf("Set Blue Tooth Off Successfully.\n");
			else if (BlueToothState == ASR_ENABLED)
				printf("Set Blue Tooth On Successfully.\n");
			else
				printf("Set Blue Tooth failed !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetBTState((UCHAR)BlueToothState, Usage);
	}

	return 0;
}

int GetWifiState(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetWifiState(&State, Usage))
		{
			if (State == ASR_DISABLED)
				printf("Wifi is disable.\n");
			else if (State == ASR_ENABLED)
				printf("Wifi is enable.\n");
			else
				printf("Can't get Wifi state !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetWifiState(&State, Usage);
	}

	return 0;
}

int SetWifiState(int Usage)
{
	int WifiState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: Wifi On, 0: Wifi Off" << endl;
		cout << "Please input 1 or 0 to enable/disable Wifi:" << endl;
		cin >> WifiState;

		if (AsrLibSetWifiState((UCHAR)WifiState, Usage))
		{
			if (WifiState == ASR_DISABLED)
				printf("Set Wifi Off Successfully.\n");
			else if (WifiState == ASR_ENABLED)
				printf("Set Wifi On Successfully.\n");
			else
				printf("Set Wifi failed !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetWifiState((UCHAR)WifiState, Usage);
	}

	return 0;
}

int GetOTPState(int Usage) // 0: Disable, 1: Enable
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetOTPState(&State, Usage))
		{
			if (State == ASR_ENABLED)
				printf("Over Temperature Protection is enable.\n");
			else if (State == ASR_DISABLED)
				printf("Over Temperature Protection is disable.\n");
			else
				printf("Can't get OTP state !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetOTPState(&State, Usage);
	}

	return 0;
}

int GetATModeState(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetATModeState(&State, Usage))
		{
			if (State == ASR_ENABLED)
				printf("AT Mode is enable.\n");
			else if (State == ASR_DISABLED)
				printf("AT Mode is disable.\n");
			else
				printf("Can't get AT Mode !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetATModeState(&State, Usage);
	}

	return 0;
}

int GetDigitalIOState(int Usage) // 0: Output_Low; 1: Output_High; 2: Input_Low; 3: Input_High;
{
	int GPIONum = 0x0;
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
	//	cout << "0: GPIO_0, 1: GPIO_1, 2: GPIO_2, 3: GPIO_3, 4: GPIO_4, 5: GPIO_5..." << endl;
	  //     cout << "Please input a number to get GPIO_# state:" << endl;
		//cin >> GPIONum;
		//printf("usage_%d.\n",Usage);
		if (GPIONum >= 0)
		{
			
	              if(GPIONum == 0)
	              {
			if (AsrLibGetDigitalIOState((UCHAR)GPIONum, &State, Usage))
			{
				if (State == ASR_OUTPUT_LOW)
					printf("EMG.OFF_%d ON.\n", GPIONum);
				else if (State == ASR_OUTPUT_HIGH)
					printf("EMG.OFF_%d OFF.\n", GPIONum);
				else if (State == ASR_INPUT_LOW)
					printf("EMG.OFF_%d ON.\n", GPIONum);
				else if (State == ASR_INPUT_HIGH)
					printf("EMG.OFF_%d OFF.\n", GPIONum);
				else if (State == ASR_TGPIO)
					printf("GPIO_%d is TGPIO.\n", GPIONum);
				else
					printf("Can't get GPIO_%d state !!\n", GPIONum);
			}
			
			
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		     }
		   }
		int GPIONum = 0x2;
		if(GPIONum == 2)
		{
		   if (AsrLibGetDigitalIOState((UCHAR)GPIONum, &State, Usage))
			{
				if (State == ASR_OUTPUT_LOW)
					printf("EMG.STOP_%d ON.\n", GPIONum);
				else if (State == ASR_OUTPUT_HIGH)
					printf("EMG.STOP_%d OFF.\n", GPIONum);
				else if (State == ASR_INPUT_LOW)
					printf("EMG.STOP_%d ON.\n", GPIONum);
				else if (State == ASR_INPUT_HIGH)
					printf("EMG.STOP_%d OFF.\n", GPIONum);
				else if (State == ASR_TGPIO)
					printf("GPIO_%d is TGPIO.\n", GPIONum);
				else
					printf("Can't get GPIO_%d state !!\n", GPIONum);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		
			}
		
		/*
		else
		{
		      if (AsrLibGetDigitalIOState((UCHAR)GPIONum, &State, Usage))
			{
				if (State == ASR_OUTPUT_LOW)
					printf("GPIO_%d ON.\n", GPIONum);
				else if (State == ASR_OUTPUT_HIGH)
					printf("GPIO_%d OFF.\n", GPIONum);
				else if (State == ASR_INPUT_LOW)
					printf("GPIO_%d ON.\n", GPIONum);
				else if (State == ASR_INPUT_HIGH)
					printf("GPIO_%d OFF.\n", GPIONum);
				else if (State == ASR_TGPIO)
					printf("GPIO_%d is TGPIO.\n", GPIONum);
				else
					printf("Can't get GPIO_%d state !!\n", GPIONum);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
                }*/
                }
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetDigitalIOState(GPIONum, &State, Usage);
	}

	return 0;
}

int SetDigitalIOState(int Usage) // 0: Output_Low; 1: Output_High; 2: Input;
{
	int GPIONum = 0;
	int State = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "0: GPIO_0, 1: GPIO_1, 2: GPIO_2, 3: GPIO_3, 4: GPIO_4, 5: GPIO_5..." << endl;
		cout << "Please input a number to select GPIO_#: " << endl;
		cin >> GPIONum;
		cout << "0: Output_Low, 1: Output_High, 2: Input, 4: TGPIO" << endl;
		cout << "Please input a number to configure GPIO" << endl;
		cin >> State;

		if (GPIONum >= 0 && (State == 0 || State == 1 || State == 2 || State == 4))
		{
			if (!AsrLibSetDigitalIOState((UCHAR)GPIONum, (UCHAR)State, Usage))
				DisplayError(AsrLibDllGetLastError());
		}
		else
			printf("Input error !!\n");
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetDigitalIOState((UCHAR)GPIONum, (UCHAR)State, Usage);
	}

	return 0;
}

int GetDioConfig(int Usage)
{
	int GPIONum = 0xFF;
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "0: GPIO_0, 1: GPIO_1, 2: GPIO_2, 3: GPIO_3, 4: GPIO_4, 5: GPIO_5..." << endl;
		cout << "Please input a number to get GPIO_# state:" << endl;
		cin >> GPIONum;

		if (GPIONum >= 0)
		{
			if (AsrLibGetDioConfig((UCHAR)GPIONum, &State, Usage))
			{
				if (State == ASR_HIGH_SIDE)
					printf("GPIO_%d is High-Side mode.\n", GPIONum);
				else if (State == ASR_PUSH_PULL)
					printf("GPIO_%d is Push-Pull.\n", GPIONum);
				else
					printf("Can't get GPIO_%d config(mode) !!\n", GPIONum);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetDioConfig(GPIONum, &State, Usage);
	}

	return 0;
}

int SetDioConfig(int Usage)
{
	int GPIONum = 0;
	int State = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "0: GPIO_0, 1: GPIO_1, 2: GPIO_2, 3: GPIO_3, 4: GPIO_4, 5: GPIO_5..." << endl;
		cout << "Please input a number to select GPIO_#: " << endl;
		cin >> GPIONum;
		cout << "0: High-Side, 1: Push-Pull" << endl;
		cout << "Please input a number to configure GPIO" << endl;
		cin >> State;

		if (GPIONum >= 0 && (State == 0 || State == 1))
		{
			if (!AsrLibSetDioConfig((UCHAR)GPIONum, (UCHAR)State, Usage))
				DisplayError(AsrLibDllGetLastError());
		}
		else
			printf("Input error !!\n");
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetDioConfig((UCHAR)GPIONum, (UCHAR)State, Usage);
	}

	return 0;
}


int GetDioEnPin(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetDioEnPin(&State, Usage))
		{
			if (State == ASR_DISABLED)
				printf("DIO En Pin is disable.\n");
			else if (State == ASR_ENABLED)
				printf("DIO EN Pin is enable.\n");
			else
				printf("Can't get DIO EN Pin state !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetDioEnPin(&State, Usage);
	}

	return 0;
}

int SetDioEnPin(int Usage)
{
	int DioEnState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: Enable DIO EN Pin, 0: Disable DIO EN Pin" << endl;
		cout << "Please input 1 or 0 to configure DIO EN Pin:" << endl;
		cin >> DioEnState;

		if (AsrLibSetDioEnPin((UCHAR)DioEnState, Usage))
		{
			if (DioEnState == ASR_DISABLED)
				printf("Disable DIO EN Pin Successfully.\n");
			else if (DioEnState == ASR_ENABLED)
				printf("Enable DIO EN Pin Successfully.\n");
			else
				printf("Set DIO EN Pin failed !!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetDioEnPin((UCHAR)DioEnState, Usage);
	}

	return 0;
}

int EnableWatchDogTimer(int Usage)
{
	int WDTInterval = 0xFF;
	int WDTCountMode = 0xFF; // 0: Second Mode; 1: Minute Mode

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "Please input WDT interval(0 ~ 255): " << endl;
		cin >> WDTInterval;

		if (WDTInterval < 0 || WDTInterval > 255) {
			printf("Invalidated interval value !!\n");
			return 1;
		}

		if (AsrLibWDTGetCountMode(NULL, ASR_USAGE_IF_SUPPORTED)) {
			cout << "Please intput WDT count mode(0: Second Mode; 1: Minute Mode): " << endl;
			cin >> WDTCountMode;

			if (WDTCountMode < 0 || WDTCountMode > 1) {
				printf("Invalidated timer count mode !!\n");
				return 1;
			}
		}

		if (!AsrLibWDTEnable((UCHAR)WDTInterval, (UCHAR)WDTCountMode, Usage))
			DisplayError(AsrLibDllGetLastError());
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibWDTEnable((UCHAR)WDTInterval, (UCHAR)WDTCountMode, Usage);
	}

	return 0;
}

int DisableWatchDogTimer(int Usage)
{
	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (!AsrLibWDTDisable(Usage))
			DisplayError(AsrLibDllGetLastError());
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibWDTDisable(Usage);
	}

	return 0;
}

int GetWatchDogInterval(int Usage)
{
	int WDTInterval = 0;
	UCHAR CountMode = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibWDTGetInterval(&WDTInterval, Usage))
		{
			AsrLibWDTGetCountMode(&CountMode, Usage);
			if (CountMode == 1)
				printf("WDT Time Interval is %d minutes.\n", WDTInterval);
			else
				printf("WDT Time Interval is %d seconds.\n", WDTInterval);
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibWDTGetInterval(&WDTInterval, Usage);
	}

	return 0;
}

int SetWatchDogInterval(int Usage)
{
	int WDTInterval = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "Please input WDT interval(0 ~ 255): " << endl;
		cin >> WDTInterval;

		if (WDTInterval >= 0 && WDTInterval <= 255)
		{
			if (!AsrLibWDTSetInterval((UCHAR)WDTInterval, Usage))
				DisplayError(AsrLibDllGetLastError());
		}
		else
		{
			printf("Invalidation value !!\n");
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibWDTSetInterval((UCHAR)WDTInterval, Usage);
	}

	return 0;
}

int GetFANConfig(int Usage)
{
	if (Usage == ASR_USAGE_CUSTOMER)
	{
		UCHAR FANMode = 0xFF;
		UCHAR FANParamCount = MAX_PARAM_COUNT;
		char FanName[ASR_ITEM_NAME_SIZE] = "";

		printf("Input the FAN name which should be less than %lu characters:\n", sizeof(FanName));

		cin.ignore(IGNORE_STREAM_BUFFER_SIZE, '\n');
		cin.getline(FanName, ASR_ITEM_NAME_SIZE);
#ifdef _DEBUG
		printf("GetFANConfig::FanName = %s\n", FanName);
#endif

		if (!AsrLibGetFANConfig(FanName, &FANMode, &FANParamCount, Usage))
		{
			DisplayError(AsrLibDllGetLastError());
			return 0;
		}
#ifdef _DEBUG
		printf("GetFANConfig::FANMode = %d, FANParamCount = %d\n", FANMode, FANParamCount);
#endif

		UCHAR *FANConfig = new UCHAR[FANParamCount]{ 0 };

		*FANConfig = FANMode;
		if (AsrLibGetFANConfig(FanName, FANConfig, &FANParamCount, Usage))
		{
			for (int i = 0; i < FANParamCount; i++)
			{
				if(i == 0)
					printf("Current FAN Mode is %d\n", *(FANConfig + i));
				else
					printf("FAN Config Parameter[%d] = 0x%X\n", i, *(FANConfig + i));
			}
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}

		delete[] FANConfig;
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetFANConfig(NULL, NULL, NULL, Usage);
	}

	return 0;
}

int SetFANConfig(int Usage)
{
	if (Usage == ASR_USAGE_CUSTOMER)
	{
		int FANMode = 0xFF;
		int FANParam = 0;
		char FanName[ASR_ITEM_NAME_SIZE] = "";

		printf("Input the FAN name which should be less than %lu characters:\n", sizeof(FanName));

		cin.ignore(IGNORE_STREAM_BUFFER_SIZE, '\n');
		cin.getline(FanName, ASR_ITEM_NAME_SIZE);
#ifdef _DEBUG
		printf("SetFANConfig::FanName = %s\n", FanName);
#endif

		UCHAR FANModeSupport = 0;
		AsrLibGetFANModeSupport(FanName, &FANModeSupport);
#ifdef _DEBUG
		printf("SetFANConfig::FANModeSupport = 0x%X\n", FANModeSupport);
#endif

		UCHAR SioNum = 0;
		AsrLibGetWhichIOToBeUse(0x1A, FanName, &SioNum);

		cout << "0: Manual Mode; 1: Auto Mode; 2: Smart FAN 4" << endl;
		cout << "Please input 0 ~ 2 to select FAN mode : " << endl;
		cin >> FANMode;

		if (FANMode == 0 && (FANModeSupport & ASR_FAN_MODE0_MASK)) // Manual Mode
		{
			UCHAR *FANConfig = new UCHAR[2]{ 0 };
			*FANConfig = (UCHAR)FANMode;

			if(SioNum  == 4) // MCU FAN
				cout << "Please input PWM duty(0 ~ 100): " << endl;
			else
				cout << "Please input PWM duty(0 ~ 255): " << endl;

			cin >> FANParam;
			*(FANConfig + 1) = (UCHAR)FANParam;

			if(!AsrLibSetFANConfig(FanName, FANConfig, 2, Usage))
				DisplayError(AsrLibDllGetLastError());

			delete[] FANConfig;
		}
		else if (FANMode == 1 && (FANModeSupport & ASR_FAN_MODE1_MASK)) // Auto Mode
		{
			UCHAR *FANConfig = new UCHAR[3]{ 0 };
			*FANConfig = (UCHAR)FANMode;

			cout << "Please input target temperature(0 ~ 255): " << endl;
			cin >> FANParam;
			*(FANConfig + 1) = (UCHAR)FANParam;

			if (SioNum == 4) // MCU FAN
				cout << "Please input target PWM duty(0 ~ 100): " << endl;
			else
				cout << "Please input target PWM duty(0 ~ 255): " << endl;

			cin >> FANParam;
			*(FANConfig + 2) = (UCHAR)FANParam;

			if(!AsrLibSetFANConfig(FanName, FANConfig, 3, Usage))
				DisplayError(AsrLibDllGetLastError());

			delete[] FANConfig;
		}
		else if (FANMode == 2 && (FANModeSupport & ASR_FAN_MODE2_MASK)) // Smart FAN 4
		{
			UCHAR ParamCount = GetSIOSmartFAN4ParamCount(SioNum);
#ifdef _DEBUG
			printf("SetFANConfig::ParamCount : %d\n", ParamCount);
#endif
			if (ParamCount == 0xFF)
			{
#ifdef _DEBUG
				printf("SetFANConfig::FANMode2::ParamCount error !!\n");
#endif
				return 0;
			}

			UCHAR *FANConfig = new UCHAR[ParamCount]{ 0 };
			*FANConfig = (UCHAR)FANMode;

			cout << "parameter[0](FAN mode) : " << (int)*FANConfig << endl;
			for (int i = 1; i < ParamCount; i++)
			{
				cout << "Please input parameter[" << i << "]: " << endl;
				cin >> FANParam;
				*(FANConfig + i) = (UCHAR)FANParam;
			}

			if(!AsrLibSetFANConfig(FanName, FANConfig, ParamCount, Usage))
				DisplayError(AsrLibDllGetLastError());

			delete[] FANConfig;
		}
		else
		{
			cout << "This model does not support FANMode " << FANMode << endl;
			return 0;
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetFANConfig(NULL, NULL, 0, Usage);
	}

	return 0;
}

// According to document to write this function
UCHAR GetSIOSmartFAN4ParamCount(UCHAR SioNum)
{
	UCHAR SmartFAN4ParamCount = 0xFF;

	switch (SioNum)
	{
		case 1: // Fintek 81966
		case 4: // MCU 121
			SmartFAN4ParamCount = 10; // FAN Mode + 4 Temperature + 5 PWM Duty
			break;
		case 2: // Nuvoton 6126D
		case 3: // Nuvoton 5525D
		case 5: // Nuvoton 5525D-S
		case 6: // Nuvoton 6796D-S
		case 7: // Nuvoton 6126D-S
			SmartFAN4ParamCount = 11; // FAN Mode + 5 Temperature + 5 PWM Duty
			break;
		default:
			break;
	}

	return SmartFAN4ParamCount;
}

int GetVoltageNames(int Usage)
{
	char **VoltageNames = NULL;
	UCHAR VoltageNamesCount = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetVoltageNames(VoltageNames, &VoltageNamesCount, Usage))
		{
#ifdef _DEBUG
			printf("GetVoltageNames::VoltageNamesCount = %d\n", (int)VoltageNamesCount);
#endif
			VoltageNames = new char*[VoltageNamesCount];
			for (int i = 0; i < VoltageNamesCount; i++)
				VoltageNames[i] = new char[ASR_ITEM_NAME_SIZE];

			if (AsrLibGetVoltageNames(VoltageNames, &VoltageNamesCount, Usage))
			{
				for (int i = 0; i < VoltageNamesCount; i++)
					printf("%s\n", VoltageNames[i]);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}

			for (int i = 0; i < VoltageNamesCount; i++)
				delete[] VoltageNames[i];

			delete[] VoltageNames;
			VoltageNames = NULL;
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetVoltageNames(VoltageNames, &VoltageNamesCount, Usage);
	}

	return 0;
}

int GetTemperatureNames(int Usage)
{
	char **TemperatureNames = NULL;
	UCHAR TemperatureNamesCount = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetTemperatureNames(TemperatureNames, &TemperatureNamesCount, Usage))
		{
#ifdef _DEBUG
			printf("GetTemperatureNames::TemperatureNamesCount = %d\n", (int)TemperatureNamesCount);
#endif
			TemperatureNames = new char*[TemperatureNamesCount];
			for (int i = 0; i < TemperatureNamesCount; i++)
				TemperatureNames[i] = new char[ASR_ITEM_NAME_SIZE];

			if (AsrLibGetTemperatureNames(TemperatureNames, &TemperatureNamesCount, Usage))
			{
				for (int i = 0; i < TemperatureNamesCount; i++)
					printf("%s\n", TemperatureNames[i]);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}

			for (int i = 0; i < TemperatureNamesCount; i++)
				delete[] TemperatureNames[i];

			delete[] TemperatureNames;
			TemperatureNames = NULL;
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetTemperatureNames(TemperatureNames, &TemperatureNamesCount, Usage);
	}

	return 0;
}

int GetFanSpeedNames(int Usage)
{
	char **FanSpeedNames = NULL;
	UCHAR FanSpeedNamesCount = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetFanSpeedNames(FanSpeedNames, &FanSpeedNamesCount, Usage))
		{
#ifdef _DEBUG
			printf("GetFanSpeedNames::FanSpeedNamesCount = %d\n", (int)FanSpeedNamesCount);
#endif
			FanSpeedNames = new char*[FanSpeedNamesCount];
			for (int i = 0; i < FanSpeedNamesCount; i++)
				FanSpeedNames[i] = new char[ASR_ITEM_NAME_SIZE];

			if (AsrLibGetFanSpeedNames(FanSpeedNames, &FanSpeedNamesCount, Usage))
			{
				for (int i = 0; i < FanSpeedNamesCount; i++)
					printf("%s\n", FanSpeedNames[i]);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}

			for (int i = 0; i < FanSpeedNamesCount; i++)
				delete[] FanSpeedNames[i];

			delete[] FanSpeedNames;
			FanSpeedNames = NULL;
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetFanSpeedNames(FanSpeedNames, &FanSpeedNamesCount, Usage);
	}

	return 0;
}

int GetCurrentNames(int Usage)
{
	char **CurrentNames = NULL;
	UCHAR CurrentNamesCount = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetCurrentNames(CurrentNames, &CurrentNamesCount, Usage))
		{
#ifdef _DEBUG
			printf("GetCurrentNames::CurrentNamesCount = %d\n", (int)CurrentNamesCount);
#endif
			CurrentNames = new char*[CurrentNamesCount];
			for (int i = 0; i < CurrentNamesCount; i++)
				CurrentNames[i] = new char[ASR_ITEM_NAME_SIZE];

			if (AsrLibGetCurrentNames(CurrentNames, &CurrentNamesCount, Usage))
			{
				for (int i = 0; i < CurrentNamesCount; i++)
					printf("%s\n", CurrentNames[i]);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}

			for (int i = 0; i < CurrentNamesCount; i++)
				delete[] CurrentNames[i];

			delete[] CurrentNames;
			CurrentNames = NULL;
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetCurrentNames(CurrentNames, &CurrentNamesCount, Usage);
	}

	return 0;
}

int GetFANConfigNames(int Usage)
{
	char **FANConfigNames = NULL;
	UCHAR FANConfigNamesCount = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetFanConfigNames(FANConfigNames, &FANConfigNamesCount, Usage))
		{
#ifdef _DEBUG
			printf("GetFANConfigNames::FANConfigNamesCount = %d\n", (int)FANConfigNamesCount);
#endif
			FANConfigNames = new char*[FANConfigNamesCount];
			for (int i = 0; i < FANConfigNamesCount; i++)
				FANConfigNames[i] = new char[ASR_ITEM_NAME_SIZE];

			if (AsrLibGetFanConfigNames(FANConfigNames, &FANConfigNamesCount, Usage))
			{
				for (int i = 0; i < FANConfigNamesCount; i++)
					printf("%s\n", FANConfigNames[i]);
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}

			for (int i = 0; i < FANConfigNamesCount; i++)
				delete[] FANConfigNames[i];

			delete[] FANConfigNames;
			FANConfigNames = NULL;
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetFanConfigNames(FANConfigNames, &FANConfigNamesCount, Usage);
	}

	return 0;
}

int BacklightControl(int Usage)
{
	int LVDSCtrlState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "0: Darken, 1: Brighten" << endl;
		cout << "Please input 0 or 1 to darken or brighten the backlight:" << endl;
		cin >> LVDSCtrlState;

		if (LVDSCtrlState != 1 && LVDSCtrlState != 0)
		{
			printf("Parameter error !!\n");
			return 1;
		}

		if (AsrLibBacklightCtrl((UCHAR)LVDSCtrlState, Usage))
		{
			if (LVDSCtrlState == 1)
				printf("Brighten the backlight.\n");
			else if (LVDSCtrlState == 0)
				printf("Darken the backlight.\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibBacklightCtrl((UCHAR)LVDSCtrlState, Usage);
	}

	return 0;
}

int GetUserLEDState(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetUserLEDState(&State, Usage))
		{
			if (State == ASR_USER_LED_ENABLE)
				printf("User LED is enable.\n");
			else if (State == ASR_USER_LED_DISABLE)
				printf("User LED is disable!!\n");
			else
				printf("Can't get User LED state!!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetUserLEDState(&State, Usage);
	}

	return 0;
}

int SetUserLEDState(int Usage)
{
	int UserLEDState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: Enable User LED, 0: Disable User LED" << endl;
		cout << "Please input 1 or 0 to enable/disable User LED:" << endl;
		cin >> UserLEDState;

		if (UserLEDState != ASR_USER_LED_DISABLE && UserLEDState != ASR_USER_LED_ENABLE)
		{
			printf("Parameter error !!\n");
			return 1;
		}

		if (AsrLibSetUserLEDState((UCHAR)UserLEDState, Usage))
		{
			if (UserLEDState == ASR_USER_LED_DISABLE)
				printf("Disable User LED Successfully.\n");
			else if (UserLEDState == ASR_USER_LED_ENABLE)
				printf("Enable User LED Successfully.\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetUserLEDState((UCHAR)UserLEDState, Usage);
	}

	return 0;
}

int GetUserLEDColor(int Usage)
{
	int LED_Num = 0;
	UCHAR Color = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: USER_LED1, 2: USER_LED2..." << endl;
		cout << "Please input a number to get USER_LED# color: " << endl;
		cin >> LED_Num;

		if (LED_Num > 0)
		{
			if (AsrLibGetUserLEDColor((UCHAR)LED_Num, &Color, Usage))
			{
				if (Color == ASR_USER_LED_WHITE)
					printf("USER_LED is white\n");
				else if (Color == ASR_USER_LED_PINK)
					printf("USER_LED is pink\n");
				else if (Color == ASR_USER_LED_YELLOW)
					printf("USER_LED is yellow\n");
				else if (Color == ASR_USER_LED_RED)
					printf("USER_LED is red\n");
				else if (Color == ASR_USER_LED_DARKGREEN)
					printf("USER_LED is darkgreen\n");
				else if (Color == ASR_USER_LED_BLUE)
					printf("USER_LED is blue\n");
				else if (Color == ASR_USER_LED_GREEN)
					printf("USER_LED is green\n");
				else if (Color == ASR_USER_LED_OFF)
					printf("USER_LED is off\n");
				else
					printf("Can't get USER_LED color!!\n");
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetUserLEDColor((UCHAR)LED_Num, &Color, Usage);
	}

	return 0;
}

int SetUserLEDColor(int Usage)
{
	int LED_Num = 0;
	int UserLEDColor = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: USER_LED1, 2: USER_LED2..." << endl;
		cout << "Please input a number to choose USER_LED#: " << endl;
		cin >> LED_Num;
		cout << "0: White, 1: Pink, 2: Yellow, 3:Red, 4:Darkgreen, 5:Blue, 6:Green, 7:Off" << endl;
		cout << "Please input 0 ~ 7 to set USER_LED" << LED_Num << " color:" << endl;
		cin >> UserLEDColor;

		if (LED_Num > 0 && UserLEDColor >= 0)
		{
			if (AsrLibSetUserLEDColor((UCHAR)LED_Num, (UCHAR)UserLEDColor, Usage))
			{
				if (UserLEDColor == ASR_USER_LED_WHITE)
					printf("Set USER_LED white\n");
				else if (UserLEDColor == ASR_USER_LED_PINK)
					printf("Set USER_LED pink\n");
				else if (UserLEDColor == ASR_USER_LED_YELLOW)
					printf("Set USER_LED yellow\n");
				else if (UserLEDColor == ASR_USER_LED_RED)
					printf("Set USER_LED red\n");
				else if (UserLEDColor == ASR_USER_LED_DARKGREEN)
					printf("Set USER_LED darkgreen\n");
				else if (UserLEDColor == ASR_USER_LED_BLUE)
					printf("Set USER_LED blue\n");
				else if (UserLEDColor == ASR_USER_LED_GREEN)
					printf("Set USER_LED green\n");
				else if (UserLEDColor == ASR_USER_LED_OFF)
					printf("Set USER_LED off\n");
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
		else
		{
			printf("Parameter error !!\n");
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetUserLEDColor((UCHAR)LED_Num, (UCHAR)UserLEDColor, Usage);
	}

	return 0;
}

int GetJGPIOPowerState(int Usage)
{
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		if (AsrLibGetJGPIOPowerState(&State, Usage))
		{
			if (State == ASR_JGPIO_POWER_OFF)
				printf("JGPIO power is off\n");
			else if (State == ASR_JGPIO_POWER_3V)
				printf("JGPIO power is 3V\n");
			else if (State == ASR_JGPIO_POWER_5V)
				printf("JGPIO power is 5V\n");
			else
				printf("Can't get JGPIO power state!!\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetJGPIOPowerState(&State, Usage);
	}

	return 0;
}

int SetJGPIOPowerState(int Usage)
{
	int JGPIOState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "0: OFF, 1: 3V, 2: 5V" << endl;
		cout << "Please input 0 ~ 2 to set JGPIO power:" << endl;
		cin >> JGPIOState;

		if (JGPIOState < 0 || JGPIOState > 2)
		{
			printf("Parameter error !!\n");
			return 1;
		}

		if (AsrLibSetJGPIOPowerState((UCHAR)JGPIOState, Usage))
		{
			if (JGPIOState == ASR_JGPIO_POWER_OFF)
				printf("Set JGPIO power OFF\n");
			else if (JGPIOState == ASR_JGPIO_POWER_3V)
				printf("Set JGPIO power to be 3V\n");
			else if (JGPIOState == ASR_JGPIO_POWER_5V)
				printf("Set JGPIO power to be 5V\n");
		}
		else
		{
			DisplayError(AsrLibDllGetLastError());
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetJGPIOPowerState((UCHAR)JGPIOState, Usage);
	}

	return 0;
}

int GetCOMPowerState(int Usage)
{
	int ComNum = 0;
	UCHAR State = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: COM1, 2: COM2, 3: COM3, 4: COM4, 5: COM5, 6: COM6..." << endl;
		cout << "Please input a number to get COM# power: " << endl;
		cin >> ComNum;

		if (ComNum > 0)
		{
			if (AsrLibGetCOMPowerState((UCHAR)ComNum, &State, Usage))
			{
				if (State == ASR_COM_POWER_OFF)
					printf("COM power is off\n");
				else if (State == ASR_COM_POWER_5V)
					printf("COM power is 5V\n");
				else if (State == ASR_COM_POWER_12V)
					printf("COM power is 12V\n");
				else
					printf("Can't get COM power state!!\n");
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetCOMPowerState((UCHAR)ComNum, &State, Usage);
	}

	return 0;
}

int SetCOMPowerState(int Usage)
{
	int ComNum = 0;
	int COMPowerState = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: COM1, 2: COM2, 3: COM3, 4: COM4, 5: COM5, 6: COM6 ..." << endl;
		cout << "Please input a number to choose COM#: " << endl;
		cin >> ComNum;
		cout << "0: OFF, 1: 5V, 2: 12V" << endl;
		cout << "Please input 0 ~ 2 to set COM" << ComNum << " power:" << endl;
		cin >> COMPowerState;

		if (ComNum > 0 && COMPowerState >= 0)
		{
			if (AsrLibSetCOMPowerState((UCHAR)ComNum, (UCHAR)COMPowerState, Usage))
			{
				if (COMPowerState == ASR_COM_POWER_OFF)
					printf("Set COM power OFF\n");
				else if (COMPowerState == ASR_COM_POWER_5V)
					printf("Set COM power to be 5V\n");
				else if (COMPowerState == ASR_COM_POWER_12V)
					printf("Set COM power to be 12V\n");
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
		else
		{
			printf("Parameter error !!\n");
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetCOMPowerState((UCHAR)ComNum, (UCHAR)COMPowerState, Usage);
	}

	return 0;
}

int GetDbgLedColor(int Usage)
{
	int LED_Num = 0;
	UCHAR Color = 0xFF;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: DBG_LED1, 2: DBG_LED2..." << endl;
		cout << "Please input a number to get DBG_LED# color: " << endl;
		cin >> LED_Num;

		if (LED_Num > 0)
		{
			if (AsrLibGetDbgLedColor((UCHAR)LED_Num, &Color, Usage))
			{
				if (Color == ASR_DBG_LED_WHITE)
					printf("DBG_LED is white\n");
				else if (Color == ASR_DBG_LED_PINK)
					printf("DBG_LED is pink\n");
				else if (Color == ASR_DBG_LED_YELLOW)
					printf("DBG_LED is yellow\n");
				else if (Color == ASR_DBG_LED_RED)
					printf("DBG_LED is red\n");
				else if (Color == ASR_DBG_LED_DARKGREEN)
					printf("DBG_LED is darkgreen\n");
				else if (Color == ASR_DBG_LED_BLUE)
					printf("DBG_LED is blue\n");
				else if (Color == ASR_DBG_LED_GREEN)
					printf("DBG_LED is green\n");
				else if (Color == ASR_DBG_LED_OFF)
					printf("DBG_LED is off\n");
				else
					printf("Can't get DBG_LED color!!\n");
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibGetDbgLedColor((UCHAR)LED_Num, &Color, Usage);
	}

	return 0;
}

int SetDbgLedColor(int Usage)
{
	int LED_Num = 0;
	int DbgLedColor = 0;

	if (Usage == ASR_USAGE_CUSTOMER)
	{
		cout << "1: DBG_LED1, 2: DBG_LED2..." << endl;
		cout << "Please input a number to choose DBG_LED#: " << endl;
		cin >> LED_Num;
		cout << "0: White, 1: Pink, 2: Yellow, 3:Red, 4:Darkgreen, 5:Blue, 6:Green, 7:Off" << endl;
		cout << "Please input 0 ~ 7 to set DBG_LED" << LED_Num << " color:" << endl;
		cin >> DbgLedColor;

		if (LED_Num > 0 && DbgLedColor >= 0)
		{
			if (AsrLibSetDbgLedColor((UCHAR)LED_Num, (UCHAR)DbgLedColor, Usage))
			{
				if (DbgLedColor == ASR_DBG_LED_WHITE)
					printf("Set DBG_LED white\n");
				else if (DbgLedColor == ASR_DBG_LED_PINK)
					printf("Set DBG_LED pink\n");
				else if (DbgLedColor == ASR_DBG_LED_YELLOW)
					printf("Set DBG_LED yellow\n");
				else if (DbgLedColor == ASR_DBG_LED_RED)
					printf("Set DBG_LED red\n");
				else if (DbgLedColor == ASR_DBG_LED_DARKGREEN)
					printf("Set DBG_LED darkgreen\n");
				else if (DbgLedColor == ASR_DBG_LED_BLUE)
					printf("Set DBG_LED blue\n");
				else if (DbgLedColor == ASR_DBG_LED_GREEN)
					printf("Set DBG_LED green\n");
				else if (DbgLedColor == ASR_DBG_LED_OFF)
					printf("Set DBG_LED off\n");
			}
			else
			{
				DisplayError(AsrLibDllGetLastError());
			}
		}
		else
		{
			printf("Parameter error !!\n");
		}
	}
	else if (Usage == ASR_USAGE_IF_SUPPORTED)
	{
		return AsrLibSetDbgLedColor((UCHAR)LED_Num, (UCHAR)DbgLedColor, Usage);
	}

	return 0;
}
