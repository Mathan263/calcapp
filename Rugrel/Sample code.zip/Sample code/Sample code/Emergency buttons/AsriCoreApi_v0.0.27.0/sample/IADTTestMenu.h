#ifndef IADTTESTMENUH
#define IADTTESTMENUH

#include "AsrCore.h"

//==================================================================
typedef unsigned char				UCHAR;
typedef unsigned short				USHORT;
typedef unsigned long				ULONG;

typedef int(*IADTFunctions)(int);

typedef struct IADTFunctionArray {
	char FunctionName[50];
	IADTFunctions IADTFunc;
} TIADTFunctionArray;
//==================================================================
int GetCOMType(int Usage);
int SetCOMType(int Usage);
int GetVoltageNames(int Usage);
int GetVoltage(int Usage);
int GetTemperatureNames(int Usage);
int GetTemperature(int Usage);
int GetFanSpeedNames(int Usage);
int GetFanSpeed(int Usage);
int GetCurrentNames(int Usage);
int GetCurrent(int Usage);
int GetLVDSState(int Usage);
int GetLVDSType(int Usage);
int GetOnboardTPMState(int Usage);
int GetUSBPwrState(int Usage);
int SetUSBPwrState(int Usage);
int GetBlueToothState(int Usage);
int SetBlueToothState(int Usage);
int GetWifiState(int Usage);
int SetWifiState(int Usage);
int GetOTPState(int Usage);			// 0:Disable; 1:Enable
int GetATModeState(int Usage);
int GetDigitalIOState(int Usage);
int SetDigitalIOState(int Usage);
int GetDioConfig(int Usage);
int SetDioConfig(int Usage);
int GetDioEnPin(int Usage);
int SetDioEnPin(int Usage);
int EnableWatchDogTimer(int Usage);
int DisableWatchDogTimer(int Usage);
int GetWatchDogInterval(int Usage);
int SetWatchDogInterval(int Usage);
int GetFANConfigNames(int Usage);
int GetFANConfig(int Usage);
int SetFANConfig(int Usage);
int BacklightControl(int Usage);
int GetUserLEDState(int Usage);
int SetUserLEDState(int Usage);
int GetUserLEDColor(int Usage); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF
int SetUserLEDColor(int Usage); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF
int GetJGPIOPowerState(int Usage);
int SetJGPIOPowerState(int Usage);
int GetCOMPowerState(int Usage);
int SetCOMPowerState(int Usage);
int GetDbgLedColor(int Usage); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF
int SetDbgLedColor(int Usage); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF

unsigned char GetSIOSmartFAN4ParamCount(unsigned char SioNum);

TIADTFunctionArray IADTFuncArray[] = {
	{ "GetCOMType", GetCOMType },
	{ "SetCOMType", SetCOMType },
	{ "GetVoltageNames", GetVoltageNames },
	{ "GetVoltage", GetVoltage },
	{ "GetTemperatureNames", GetTemperatureNames },
	{ "GetTemperature", GetTemperature },
	{ "GetFanSpeedNames", GetFanSpeedNames },
	{ "GetFanSpeed", GetFanSpeed },
	{ "GetCurrentNames", GetCurrentNames },
	{ "GetCurrent", GetCurrent },
	{ "GetLVDSState", GetLVDSState },
	{ "GetLVDSType", GetLVDSType },
	{ "GetOnboardTPMState", GetOnboardTPMState },
	{ "GetUSBPwrState", GetUSBPwrState },
	{ "SetUSBPwrState", SetUSBPwrState },
	{ "GetBlueToothState", GetBlueToothState },
	{ "SetBlueToothState", SetBlueToothState },
	{ "GetWifiState", GetWifiState },
	{ "SetWifiState", SetWifiState },
	{ "GetOTPState", GetOTPState },
	{ "GetATModeState", GetATModeState },
	{ "GetDigitalIOState", GetDigitalIOState },
	{ "SetDigitalIOState", SetDigitalIOState },
	{ "GetDioConfig", GetDioConfig },
	{ "SetDioConfig", SetDioConfig },
	{ "GetDioEnPin", GetDioEnPin },
	{ "SetDioEnPin", SetDioEnPin },
	{ "EnableWatchDogTimer", EnableWatchDogTimer },
	{ "DisableWatchDogTimer", DisableWatchDogTimer },
	{ "GetWatchDogInterval", GetWatchDogInterval },
	{ "SetWatchDogInterval", SetWatchDogInterval },
	{ "GetFANConfigNames", GetFANConfigNames },
	{ "GetFANConfig", GetFANConfig },
	{ "SetFANConfig", SetFANConfig },
	{ "BacklightControl", BacklightControl },
	{ "GetUserLEDState", GetUserLEDState },
	{ "SetUserLEDState", SetUserLEDState },
	{ "GetUserLEDColor", GetUserLEDColor },
	{ "SetUserLEDColor", SetUserLEDColor },	
	{ "GetJGPIOPowerState", GetJGPIOPowerState },
	{ "SetJGPIOPowerState", SetJGPIOPowerState },
	{ "GetCOMPowerState", GetCOMPowerState },
	{ "SetCOMPowerState", SetCOMPowerState },
	{ "GetDbgLedColor", GetDbgLedColor },
	{ "SetDbgLedColor", SetDbgLedColor },
};
//==================================================================
#endif