cp libAsriCore-*.so libsafec.so.3 /lib
cp libAsriCore-*.so libsafec.so.3 /lib64