#ifndef AsrCoreH
#define AsrCoreH

#include <map>
using std::map;

#define ASR_EXPORT		extern "C" __attribute__((visibility("default")))

//============================ General Function list ========================
#define ASR_FUN_ERROR				0xFF

// ASR_COM
#define ASR_FUN_RS232				0x00
#define ASR_FUN_RS422				0x01
#define ASR_FUN_RS485				0x02
#define ASR_FUN_RS485_AUTO_FLOW		0x03

// Function Enable / Disable
#define ASR_DISABLED				0x00
#define ASR_ENABLED					0x01

// ASR_BANDWIDTH_MODE
#define ASR_BANDWIDTH_X4			0x00
#define ASR_BANDWIDTH_X8			0x01
#define ASR_BANDWIDTH_X16			0x02

// GPIO Status
#define ASR_OUTPUT_LOW				0x00
#define ASR_OUTPUT_HIGH				0x01
#define ASR_INPUT_LOW				0x02 // For Read Command
#define ASR_INPUT_HIGH				0x03 // For Read Command
#define ASR_TGPIO					0x04

#define ASR_INPUT					0x02 // For Set Command

#define ASR_HIGH_SIDE               0x00
#define ASR_PUSH_PULL               0x01

#define ASR_FAN_MODE0_MASK			0x01 // Manual Mode
#define ASR_FAN_MODE1_MASK			0x02 // Auto Mode
#define ASR_FAN_MODE2_MASK			0x04 // Smart FAN 4

// User LED Control
#define ASR_USER_LED_DISABLE		0x00
#define ASR_USER_LED_ENABLE			0x01
#define ASR_USER_LED_WHITE			0x00
#define ASR_USER_LED_PINK			0x01
#define ASR_USER_LED_YELLOW			0x02
#define ASR_USER_LED_RED			0x03
#define ASR_USER_LED_DARKGREEN		0x04
#define ASR_USER_LED_BLUE			0x05
#define ASR_USER_LED_GREEN			0x06
#define ASR_USER_LED_OFF			0x07

// JGPIO Power Control
#define ASR_JGPIO_POWER_OFF			0x00
#define ASR_JGPIO_POWER_3V			0x01
#define ASR_JGPIO_POWER_5V			0x02

// COM Power Control
#define ASR_COM_POWER_OFF			0x00
#define ASR_COM_POWER_5V			0x01
#define ASR_COM_POWER_12V			0x02

// Debug LED Control
#define ASR_DBG_LED_WHITE			0x00
#define ASR_DBG_LED_PINK			0x01
#define ASR_DBG_LED_YELLOW			0x02
#define ASR_DBG_LED_RED				0x03
#define ASR_DBG_LED_DARKGREEN		0x04
#define ASR_DBG_LED_BLUE			0x05
#define ASR_DBG_LED_GREEN			0x06
#define ASR_DBG_LED_OFF				0x07
//---------------------------------------------------------------------------
#define ASR_USAGE_IF_SUPPORTED		0x00
#define ASR_USAGE_CUSTOMER			0x01
//---------------------------------------------------------------------------
#define MAX_PARAM_COUNT				0xFF
//===========================================================================
ASR_EXPORT unsigned long AsrLibDllGetLastError();

ASR_EXPORT bool AsrLibDllInit();
ASR_EXPORT bool AsrLibDllUnInit();

// IAxT >>>
ASR_EXPORT bool AsrLibGetComType(unsigned char Com_Num, unsigned char *Com_Fun, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibSetComType(unsigned char Com_Num, unsigned char Com_Fun, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetVoltage(char *VoltageName, float *Value, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetTemperature(char *TemperatureName, float *Value, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetFanSpeed(char *FanName, unsigned short *Value, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetCurrent(char *CurrentName, float *Value, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetLVDSState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibGetLVDSType(unsigned char *PanelType, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetOnboardTPMState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibGetUsbPwrState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibSetUsbPwrState(unsigned char State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibGetBTState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:ON

ASR_EXPORT bool AsrLibSetBTState(unsigned char State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:ON

ASR_EXPORT bool AsrLibGetWifiState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:ON

ASR_EXPORT bool AsrLibSetWifiState(unsigned char State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:ON

ASR_EXPORT bool AsrLibGetOTPState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibGetATModeState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibGetDigitalIOState(unsigned char GPIO_Num, unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0: Output_Low; 1: Output_High; 2: Input_Low; 3: Input_High; 4: TGPIO;

ASR_EXPORT bool AsrLibSetDigitalIOState(unsigned char GPIO_Num, unsigned char State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0: Output_Low; 1: Output_High; 2: Input; 4: TGPIO;

ASR_EXPORT bool AsrLibGetDioConfig(unsigned char GPIO_Num, unsigned char *State, unsigned char Usage); // 0: High-Side; 1: Push-Pull;

ASR_EXPORT bool AsrLibSetDioConfig(unsigned char GPIO_Num, unsigned char State, unsigned char Usage);  // 0: High-Side; 1: Push-Pull;

ASR_EXPORT bool AsrLibGetDioEnPin(unsigned char *State, unsigned char Usage); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibSetDioEnPin(unsigned char State, unsigned char Usage);  // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibWDTEnable(unsigned char TimeInterval, unsigned char TimerCountMode = 0xFF, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibWDTDisable(unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibWDTGetInterval(int *TimeInterval, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibWDTSetInterval(unsigned char TimeInterval, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibWDTGetCountMode(unsigned char *TimerCountMode, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0: Second Mode; 1: Minute Mode;

ASR_EXPORT bool AsrLibWDTSetCountMode(unsigned char TimerCountMode, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0: Second Mode; 1: Minute Mode;

ASR_EXPORT bool AsrLibGetFANConfig(char *FanName, unsigned char *FANConfig, unsigned char *ParameterCount, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibSetFANConfig(char *FanName, unsigned char *FANConfig, unsigned char ParameterCount, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT void AsrLibGetFANModeSupport(char *FanName, unsigned char *FANModeSupport/*, unsigned char Usage = ASR_USAGE_CUSTOMER*/);

ASR_EXPORT void AsrLibGetWhichIOToBeUse(unsigned char MethodGroup, char *FunName, unsigned char *IONum/*, unsigned char Usage = ASR_USAGE_CUSTOMER*/); // This function get FanName and ouput SioName

ASR_EXPORT bool AsrLibGetVoltageNames(char** VoltageNames, unsigned char *Count, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetTemperatureNames(char** TemperatureNames, unsigned char *Count, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetFanSpeedNames(char** FanNames, unsigned char *Count, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetCurrentNames(char** CurrentNames, unsigned char *Count, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibGetFanConfigNames(char** FanNames, unsigned char *Count, unsigned char Usage = ASR_USAGE_CUSTOMER);

ASR_EXPORT bool AsrLibBacklightCtrl(unsigned char UpDownCtrl, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0: Down; 1: Up

ASR_EXPORT bool AsrLibGetUserLEDState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibSetUserLEDState(unsigned char State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:Disable; 1:Enable

ASR_EXPORT bool AsrLibGetUserLEDColor(unsigned char LED_Num, unsigned char *Color, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF

ASR_EXPORT bool AsrLibSetUserLEDColor(unsigned char LED_Num, unsigned char Color, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF

ASR_EXPORT bool AsrLibGetJGPIOPowerState(unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:+3V; 2:+5V

ASR_EXPORT bool AsrLibSetJGPIOPowerState(unsigned char State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:+3V; 2:+5V

ASR_EXPORT bool AsrLibGetCOMPowerState(unsigned char Com_Num, unsigned char *State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:+5V; 2:+12V

ASR_EXPORT bool AsrLibSetCOMPowerState(unsigned char Com_Num, unsigned char State, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:OFF; 1:+5V; 2:+12V

ASR_EXPORT bool AsrLibGetDbgLedColor(unsigned char LED_Num, unsigned char *Color, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF

ASR_EXPORT bool AsrLibSetDbgLedColor(unsigned char LED_Num, unsigned char Color, unsigned char Usage = ASR_USAGE_CUSTOMER); // 0:WHITE; 1:PINK; 2:YELLOW; 3:RED; 4:DARKGREEN; 5:BLUE; 6:GREEN; 7:OFF
// IAxT <<<

#endif // AsrCoreH
