#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#define HIDRAW_DEVICE "/dev/hidraw1"  // Replace 2 with the appropriate number

// Lookup table for mapping HID keycodes to F13-F24 keycodes
const int keycodeToFKey[12] = {
    13,14,15,16,17,18,19,20,21,22,23,24
};

int main() {
    int fd;
    unsigned char buffer[64];

    fd = open(HIDRAW_DEVICE, O_RDONLY);
    if (fd < 0) {
        perror("Failed to open HID device");
        return -1;
    }

    printf("Reading from HID device %s (press Ctrl+C to exit):\n", HIDRAW_DEVICE);

    while (1) {
        ssize_t bytesRead = read(fd, buffer, sizeof(buffer));
        if (bytesRead < 0) {
            perror("Failed to read from HID device");
            break;
        }

        // Process the keycodes
        for (ssize_t i = 0; i < bytesRead; i++) {
            unsigned char keycode = buffer[i];

           printf("%d\n", keycode);
            }
        
    }

    close(fd);
    return 0;
}
