#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <fcntl.h>

int find_hidraw_device(const char* Device_uniqueID, char* hidraw_device, size_t hidraw_device_size) 
{
    struct dirent *entry;
    DIR *dp = opendir("/sys/class/hidraw");

    if (dp == NULL) 
    {     
       perror("opendir");
        return -1;
    }

    while ((entry = readdir(dp))) {
              
        if (strstr(entry->d_name, "hidraw") == entry->d_name) {
              
            char sysfs_unique_id[128];
            char sysfs_device[256];

            snprintf(sysfs_device, sizeof(sysfs_device), "/sys/class/hidraw/%s/device", entry->d_name);
            
            FILE *vendor_file = fopen(strcat(sysfs_device, "/modalias"), "r");
            if (vendor_file == NULL) {
                continue;
            }
            fscanf(vendor_file, "%s", sysfs_unique_id);
            fclose(vendor_file);

            if (strcmp(sysfs_unique_id, Device_uniqueID) == 0) {
                snprintf(hidraw_device, hidraw_device_size, "/dev/%s", entry->d_name);
                closedir(dp);
                return 0;
            }
        }
    }

    closedir(dp);
    return -1;
}

int main() 
{
    char Device_uniqueID[] = "hid:b0003g0001v00002E8Ap0000800A";     // Replace with your USB device's vendor ID in hexadecimal
    char hidraw_device[256];
    unsigned char buffer[64];
   // const int keycodeToFKey[16] = {13,14,15,16,17,18,19,20,21,22,23,24,0,0,26,25};

    if (find_hidraw_device(Device_uniqueID,hidraw_device, sizeof(hidraw_device)) == 0) {
        printf("HIDraw device found: %s\n", hidraw_device);
    } else {
        printf("HIDraw device not found for Device_uniqueID: %s",  Device_uniqueID);
    }

    
   int fd = open(hidraw_device, O_RDONLY);
    if (fd < 0) {
        perror("Failed to open HID device");
        return -1;
    }

    printf("Reading from HID device %s (press Ctrl+C to exit):\n", hidraw_device);

    while (1) 
    {
        ssize_t bytesRead = read(fd, buffer, sizeof(buffer));
        if (bytesRead < 0) 
        {
        
            perror("Failed to read from HID device");
            break;
        }

        // Process the keycodes
        printf("\nno of bytes Read :%d\n",bytesRead);
       for (ssize_t i = 0; i < bytesRead; i++) 
        {
            unsigned char keycode = buffer[i];
            printf("byte%d:0x%02x  ",i,keycode);
       
        }
        
        //printf("0x%x",buffer[3]);
        
        printf("\n");
    }


    return 0;
}
