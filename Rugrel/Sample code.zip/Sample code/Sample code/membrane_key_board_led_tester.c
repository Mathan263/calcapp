#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <string.h>

#define SERIAL_PORT "/dev/ttyUSB0"  // Port of LED communication.

void set_parameters_of_serial_communication(int ser_fd);

int main() 
{
    int serial_port;
    char input_data[10];  // Allocate memory for user input
    char message[15];

    // Open the serial port
    serial_port = open(SERIAL_PORT, O_RDWR | O_NOCTTY);
    
    if (serial_port < 0) 
    {
        perror("Failed to open serial port");
        return 1;
    }
    
    set_parameters_of_serial_communication(serial_port);
    
    printf("LED TESTER:\n");
    printf("Send data to switch on the LEDs.\n");
    printf("Type 'STOP' or 'stop' to exit.\n");

    do {
    
        printf("Data to be sent: ");
        scanf("%9s", input_data);  // Prevent buffer overflow
        
         if(strlen(input_data) > 4)
         {
            printf("Enter only 4 characters!!!!!\n");
            continue;
         }
        sprintf(message ,"%s\n", input_data);
        // Send data over UART
        int bytes_written = write(serial_port, message, strlen(message));
        if (bytes_written < 0) 
        {
            perror("Failed to write to serial port");
        }

    } while (strcmp(input_data, "STOP") != 0 && strcmp(input_data, "stop") != 0);
   
    // Close the port
    close(serial_port);
    return 0;
}

void set_parameters_of_serial_communication(int ser_fd)
{
    struct termios options;  // UART configuration

    // Get the current serial port options
    tcgetattr(ser_fd, &options);

    // Set the baud rate to 115200
    cfsetispeed(&options, B115200);
    cfsetospeed(&options, B115200);

    // Set 8N1 (8 data bits, No parity, 1 stop bit)
    options.c_cflag &= ~PARENB; // No parity
    options.c_cflag &= ~CSTOPB; // 1 stop bit
    options.c_cflag &= ~CSIZE;  
    options.c_cflag |= CS8;     // 8 data bits

    // Apply the modified options
    tcsetattr(ser_fd, TCSANOW, &options);
}

